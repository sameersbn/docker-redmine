class ChartIssueStatus < ActiveRecord::Base
  
end
