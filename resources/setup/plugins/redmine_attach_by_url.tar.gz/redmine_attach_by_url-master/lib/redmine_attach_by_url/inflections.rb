ActiveSupport::Inflector.inflections do |inflect|
  inflect.irregular "attachment_by_url", "attachments_by_url"
  inflect.irregular "AttachmentByUrl", "AttachmentsByUrl"
end
