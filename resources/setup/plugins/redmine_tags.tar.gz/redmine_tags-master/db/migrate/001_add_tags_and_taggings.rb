class AddTagsAndTaggings < RedmineActsAsTaggableOn::Migration; end
