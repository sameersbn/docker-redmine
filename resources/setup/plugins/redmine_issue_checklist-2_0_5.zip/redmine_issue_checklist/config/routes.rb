
 match "checklist/done/:checklist_item_id" => 'issue_checklists#done'
 match "checklist/delete/:checklist_item_id" => 'issue_checklists#delete'
