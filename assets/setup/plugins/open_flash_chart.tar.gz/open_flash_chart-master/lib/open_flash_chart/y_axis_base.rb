module OpenFlashChart
  class YAxisBase < Base
    def set_vertical
      @rotate = "vertical"
    end
  end
end
