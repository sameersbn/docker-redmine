module OpenFlashChart
  class YAxis < YAxisBase ; end
end