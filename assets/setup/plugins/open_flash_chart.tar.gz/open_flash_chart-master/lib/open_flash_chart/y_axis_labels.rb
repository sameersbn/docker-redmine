module OpenFlashChart
  class YAxisLabels < Base
    def set_vertical
      @rotate = 270
    end
  end
end
